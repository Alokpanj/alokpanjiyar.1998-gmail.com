package com.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.UserClaim;
import com.service.TaxService;


@Controller
public class TaxController {
	
	@Autowired
	private TaxService taxService;
	
	@Autowired
	private Validator validator;
	
	
	@RequestMapping(value="/getTaxClaimFormPage", method= RequestMethod.GET)
	public String discountPage(@ModelAttribute("userClaim") UserClaim userClaim){
		userClaim = new UserClaim();
		return "taxclaim";
	}
	

	
	@RequestMapping(value="/claculateTax", method= RequestMethod.GET)
	public String calculateTax(UserClaim userClaim,ModelMap map, BindingResult result) {

		validator.validate(userClaim, result);
		if(result.hasErrors()){
			return "taxclaim";
		}
		else {
			double price = taxService.calculateTax(userClaim);
			map.addAttribute("expenseType", userClaim.getExpenseType());
			map.addAttribute("expenseAmount", userClaim.getExpenseAmt());
			map.addAttribute("taxClaimAmount", price);
			return "result";
		}
	}
	@ModelAttribute("expenseList")
	public List<String> populateExpense(){
		List<String> populateExpenseList=new ArrayList<>();
		populateExpenseList.add("MedicalExpense");
		populateExpenseList.add("TravelExpense");
		populateExpenseList.add("FoodExpense");
		return populateExpenseList;
	}
	
}
