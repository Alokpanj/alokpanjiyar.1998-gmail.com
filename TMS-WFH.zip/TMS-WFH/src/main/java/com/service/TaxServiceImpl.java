package com.service;

import org.springframework.stereotype.Service;

import com.model.UserClaim;

@Service
public class TaxServiceImpl implements TaxService {

	@Override
	public double calculateTax(UserClaim userClaim) {
		// TODO Auto-generated method stub
		return 0;
	}

	
}

