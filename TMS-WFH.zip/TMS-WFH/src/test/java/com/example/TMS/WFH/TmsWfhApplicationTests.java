package com.example.TMS.WFH;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TmsWfhApplicationTests {

	@Test
	void contextLoads() {
	}

}
