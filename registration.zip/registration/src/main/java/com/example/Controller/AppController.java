package com.example.Controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Model.Product;
import com.example.Repository.ProductRepository;


	@Controller
	public class AppController {
		@Autowired
		ProductRepository productRepository;
		HttpSession session;
		
		@RequestMapping("/registrationform")
		public String showregistrationform(@ModelAttribute("product")  Product product) {
			product=new com.example.Model.Product();
			//System.out.println("kkk");
			return "registrationform";
		}
		
		@RequestMapping("/save")
		public String addProduct(@Valid @ModelAttribute("product")  Product product,BindingResult bindingResult) {
			//System.out.println(bindingResult.hasErrors());
			if(bindingResult.hasErrors()) {
				System.out.println("ui details not correct");
				return "registrationform";
			}
			productRepository.save(product);
		
		return "redirect:/viewregistration";
		}
		
	
	@RequestMapping("/viewregistration")
	public String viewallProduct(Model m) {
		
		List<Product> productlist=productRepository.findAll();
		m.addAttribute("plist",productlist);
		return "viewregistration";
	}
	
	@RequestMapping("/regupdateform")
	public String updateform(@RequestParam int pid, @ModelAttribute("product")  Product product,Model model) {
		Optional<Product> pp=productRepository.findById(pid);
		System.out.println("got");
		product=pp.get();
		model.addAttribute("product",product);
	//	System.out.println(product);
		return "regupdateform";
	}
	@RequestMapping("/update")
	public String updateProduct(@ModelAttribute("product") Product product) {
		System.out.println("inside update method");
		productRepository.save(product);
		//session.removeAttribute("clist");
		//session.removeAttribute("rlist");
	return "redirect:/viewregistration";
	}
	@RequestMapping("/delete")
	public String delete(@RequestParam int pid) {
		System.out.println(pid);
		productRepository.deleteById(pid);
		System.out.println(pid+"deleted");
		//session.removeAttribute("clist");
		//session.removeAttribute("rlist");
		return "redirect:/viewregistration";
	}
	
	@RequestMapping("/search")
	public String searchbyCategory(@RequestParam String category,HttpServletRequest request,ModelMap m) {
		List<Product> catList=productRepository.getProductsByCategory(category);
	System.out.println("getting by category"+catList);
	 session=request.getSession();
	session.setAttribute("clist", catList);
	m.addAttribute("plist1", catList);
	
	List<Product> productlist=productRepository.findAll();
	m.addAttribute("plist",productlist);

	//session.removeAttribute("rlist");
			return "viewregistration";
	}
	@RequestMapping("/searchbyrange")
	public String searchbyRange(@RequestParam double min,@RequestParam double max,HttpServletRequest request,ModelMap m1)
	{
		System.out.println("inside range method");
		List<Product> rangeList=productRepository.getProductsByRange(min, max);
		System.out.println("printing rangelist"+rangeList);
	//System.out.println(catList);
	 session=request.getSession();
	session.setAttribute("rlist", rangeList);
	m1.addAttribute("rlist",rangeList);
	
	//session.removeAttribute("clist");
			return "redirect:/viewregistration";
	}

	

	
}
