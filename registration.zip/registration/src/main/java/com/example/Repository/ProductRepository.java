package com.example.Repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.Model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{

	@Query("select t from Product t where t.category = ?1")
	public List<Product> getProductsByCategory(String category);
	@Query("select t from Product t where t.price>=?1 and t.price<=?2")
	public List<Product> getProductsByRange(double min, double max);
	
}
